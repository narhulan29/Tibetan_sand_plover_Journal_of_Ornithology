

#-------------------------
# Morphological traits
#-------------------------

df1<- read.csv("TSP_biometric_data.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")
df1$right_wing <- as.numeric(df1$right_wing)
df1$right_tarsus <- as.numeric(df1$right_tarsus)
df1$Bill <- as.numeric(df1$Bill)

standard_error <- function(x) sd(x) / sqrt(length(x))

df1.1 <- subset(df1,Sex=="Male")

mean (df1.1$Weight)
standard_error(df1.1$Weight)
min(df1.1$Weight)
max(df1.1$Weight)

mean (df1.1$right_wing)
standard_error(df1.1$right_wing)
min(df1.1$right_wing)
max(df1.1$right_wing)

mean (df1.1$right_tarsus)
standard_error(df1.1$right_tarsus)
min(df1.1$right_tarsus)
max(df1.1$right_tarsus)

mean (df1.1$Bill)
standard_error(df1.1$Bill)
min(df1.1$Bill)
max(df1.1$Bill)

df1.2 <- subset(df1,Sex=="Female")

mean (df1.2$Weight)
standard_error(df1.2$Weight)
min(df1.2$Weight)
max(df1.2$Weight)

mean (df1.2$right_wing)
standard_error(df1.2$right_wing)
min(df1.2$right_wing)
max(df1.2$right_wing)

mean (df1.2$right_tarsus)
standard_error(df1.2$right_tarsus)
min(df1.2$right_tarsus)
max(df1.2$right_tarsus)

mean (df1.2$Bill)
standard_error(df1.2$Bill)
min(df1.2$Bill)
max(df1.2$Bill)

boxplot(Weight~Sex,data=df1,xlab = NULL, ylab = "Body weight (g)", 
        cex.lab = 1.5, cex.axis = 1.5)
title("a",adj = 0, cex.main=1.5)
res1 <- wilcox.test(Weight~Sex, data = df1,
                   exact = FALSE)
res1

boxplot(right_wing~Sex, data=df1, xlab = NULL, ylab = "Wing length (mm)",
        cex.lab = 1.5, cex.axis = 1.5)
title("b", adj = 0,cex.main=1.5)
res2 <- wilcox.test(right_wing~Sex, data=df1,
                    exact = FALSE)
res2

boxplot(right_tarsus~Sex, data=df1,xlab = NULL, ylab = "Tarsus length (mm)",
        cex.lab = 1.5, cex.axis = 1.5)
title("c", adj = 0,cex.main=1.5)
res3 <- wilcox.test(right_tarsus~Sex, data=df1,
                    exact = FALSE)
res3

boxplot(Bill~Sex, data=df1,xlab = NULL, ylab = "Bill length (mm)",
        cex.lab = 1.5, cex.axis = 1.5)
title("d", adj = 0,cex.main=1.5)
res4 <- wilcox.test(Bill~Sex, data=df1,
                    exact = FALSE)
res4


#-----------------------------------------
# calculating relative egg laying date
#-----------------------------------------
df_temp<- read.csv("TSP_breeding_data_orginal.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")

install.packages("lubridate")
library(lubridate)
install.packages("dplyr")
library(dplyr)

#df2$Laydate<-as.Date(as.character(df2$Laydate), "%Y%m%d")
df_temp$julian_laying_date<-yday(df_temp$Laydate)
df_temp$julian_laying_date<-as.integer(df_temp$julian_laying_date)
df_temp_mean_laying <- df_temp %>% group_by(Year) %>% filter(!is.na(julian_laying_date)) %>% summarise(mean=mean(julian_laying_date), sd=sd(julian_laying_date))
df_temp$mean_laying_date<-df_temp_mean_laying$mean[match(df_temp$Year, df_temp_mean_laying$Year)]
df_temp$Relative_laying_date<-df_temp$julian_laying_date / df_temp$mean_laying_date

#df2$hatching.date<-as.Date(as.character(df2$hatching.date), "%Y%m%d")
df_temp$julian_hatching_date<-yday(df_temp$hatching.date)
df_temp$julian_hatching_date<-as.integer(df_temp$julian_hatching_date)

# incubation period
df_temp$incubation_period <- df_temp$julian_hatching_date-df_temp$julian_laying_date

mean(na.omit(df_temp$incubation_period))
standard_error(na.omit(df_temp$incubation_period))
min(na.omit(df_temp$incubation_period))
max(na.omit(df_temp$incubation_period))

write.csv(df_temp,'TSP_breeding_data_processed.csv')


# egg measures
df2<- read.csv("TSP_breeding_data_processed.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")
View(df2)

df2.1 <- df2[c(2,3,34,11:19)]
View(df2.1)

stacked1 <- cbind(df2.1[1:3], stack(df2.1[, c(4, 7, 10)]))
stacked2 <- cbind(df2.1[1:3], stack(df2.1[, c(5, 8, 11)]))
stacked3 <- cbind(df2.1[1:3], stack(df2.1[, c(6, 9, 12)]))

df2.2 <- cbind(stacked1, stacked2, stacked3)
View(df2.2)

write.csv(df2.2,'TSP_egg_vs_laying date.csv')

df2.2<- read.csv("TSP_egg_vs_laying date.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")

df2.2_na <- na.omit(df2.2)
mean(df2.2_na$length)
standard_error(df2.2_na$length)
length(df2.2_na$length)
min(df2.2_na$length)
max(df2.2_na$length)

mean(df2.2_na$width)
standard_error(df2.2_na$width)
length(df2.2_na$width)

mean(df2.2_na$egg_volume)
standard_error(df2.2_na$egg_volume)
length(df2.2_na$egg_volume)
min(df2.2_na$egg_volume)
max(df2.2_na$egg_volume)

plot(df2.2$egg_volume~df2.2$Relative_laying_date)
hist(df2.2$egg_volume, xlab="Egg volume", main = "Histogram of egg volume")
hist(df2.2$Relative_laying_date, xlab="Relative egg-laying date", ylab="Number of nests",main = "Histogram of relative egg-laying date",
     cex.lab = 1.5, cex.axis = 1.5)


# testing if egg volume is predicted by relative egg laying date, and account for the Year as random effect
library(lmerTest) 
library(lme4) 
model_egg_volumn <- lmer(egg_volume/1000~Relative_laying_date + (1 | Year), REML = TRUE,data = df2.2)
summary_model <- summary(model_egg_volumn)
summary_model

# Calculate the Wald test statistic
coef <- fixef(model_egg_volumn)  # Estimated fixed effects
se <- sqrt(diag(vcov(model_egg_volumn)))  # Standard errors

# Specify the null hypothesis
null_value <- 0

wald_test_statistic <- (coef["Relative_laying_date"] - null_value) / se["Relative_laying_date"]
wald_test_statistic

p_value <- 1 - pchisq(wald_test_statistic^2, df = 1)
p_value


# Clutch size ~ egg laying date
df_clutch_size <- c(df2$Clutch.size)
df_clutch_size_na <- na.omit(df_clutch_size)

hist(df_clutch_size_na)
mean(df_clutch_size_na)
standard_error(df_clutch_size_na)
length(df_clutch_size_na)

model <- glmer(Clutch.size ~ Relative_laying_date + (1 | Year), data = df2, family = poisson)
isSingular(model, tol = 1e-05)
summary_model <- summary(model)
summary_model

# Calculate the Wald test statistic
coef <- fixef(model)
se <- sqrt(diag(vcov(model)))
null_value <- 0
wald_test_statistic <- (coef["Relative_laying_date"] - null_value) / se["Relative_laying_date"]
wald_test_statistic
p_value <- 1 - pchisq(wald_test_statistic^2, df = 1)
p_value

# Incubation period 
df_incu_period<- c(df2$incubation_period)
df_incu_period_na <- na.omit(df_incu_period)

hist(df_incu_period_na)
mean(df_incu_period_na)
standard_error(df_incu_period_na)
length(df_incu_period_na)


# No. nest vs day
Year <- c(2015,2015,2015,2015,2015,2015,2015,2016,2016,2016,2016,2016,2016,2016,
          2018,2018,2018,2018,2018,2018,2018,2019,2019,2019,2019,2019,2019,2019)

date <- c("Earlier than May 10",
          "May 10~16", 
          "May 17~23",
          "May 24~30",
          "May 31~June 06",
          "June 07~13",
          "June 14~20",
          "Earlier than May 10",
          "May 10~16", 
          "May 17~23",
          "May 24~30",
          "May 31~June 06",
          "June 07~13",
          "June 14~20",
          "Earlier than May 10",
          "May 10~16", 
          "May 17~23",
          "May 24~30",
          "May 31~June 06",
          "June 07~13",
          "June 14~20",
          "Earlier than May 10",
          "May 10~16", 
          "May 17~23",
          "May 24~30",
          "May 31~June 06",
          "June 07~13",
          "June 14~20")
Number_of_nest <- c(1,1,0,0,1,0,0,
                    0,0,3,1,4,0,1,
                    0,2,3,4,2,3,2,
                    0,4,3,4,9,3,1)

df3 <- data.frame(Year,date,Number_of_nest)
df3
df3$date <- as.factor(df3$date)
df3$Year <- as.factor(df3$Year)

ggplot(data=df3, aes(x=date, y=Number_of_nest, fill=Year)) +
  geom_bar(stat="identity", color="black",position=position_dodge())+
  scale_x_discrete(limits=c("Earlier than May 10","May 10~16","May 17~23","May 24~30",
                            "May 31~June 06", "June 07~13", "June 14~20","May 10~16")) +
  theme(text = element_text(size=16,face="bold"),axis.text.y = element_text(size=16,colour="black",face="bold"),axis.text.x = element_text(size=10,colour="black",face="bold"))+
  labs(title= NULL,y="Number of nests", x="Date")+scale_y_continuous(breaks=seq(0,10,2))


# nest success
df2$Year <- as.factor(df2$Year)
df2$nest.fate_2 <- as.factor(df2$nest.fate_2)

library(dplyr)
df2.3 <- df2 %>%
  filter(!is.na(nest.fate_2)) %>%
  group_by(Year, nest.fate_2) %>%
  summarise(count = n()) %>%
  group_by(Year) %>%
  mutate(percentage = (count / sum(count)) * 100)
View(df2.3)

df2.4 <- subset(df2.3, nest.fate_2=="HATCH")
mean(df2.4$percentage)
standard_error(df2.4$percentage)


# Nesting success~ egg laying date
df2.5 <- subset(df2, nest_fate !="3")

model2.1 <- glmer(nest_fate ~ Relative_laying_date + (1|Year), family = binomial (link = "logit"), data = df2.5)
isSingular(model2.1, tol = 1e-05) # TRUE
summary(model2.1)

#Wald test statistics
coef <- fixef(model2.1)  
se <- sqrt(diag(vcov(model2.1))) 
null_value <- 0
wald_test_statistic <- (coef["Relative_laying_date"] - null_value) / se["Relative_laying_date"]
wald_test_statistic
p_value <- 1 - pchisq(wald_test_statistic^2, df = 1)
p_value


library(ggplot2)
fig2.1<-ggplot(aes(y=nest_fate, x=Relative_laying_date), data=df2.5)+
  theme_bw()+
  geom_smooth(method="glm",method.args = list(family = "binomial"),se=TRUE,size=1)+
  geom_jitter( height = 0, alpha=0.5, size=2)+
  scale_x_continuous( limits = c(0.9,1.1))+scale_y_continuous(breaks=seq(0,1),limit=c(0,1.05),labels=c("Failed","Successful"))+
  labs(title= NULL,y=NULL, x="Relative egg-laying date")+ theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                                                                panel.background = element_blank(), axis.line = element_line(colour = "black"))+
  theme(text = element_text(size=12,face="bold"),axis.text.y = element_text(size=12,colour="black",face="bold"),axis.text.x = element_text(size=12,colour="black",face="bold"),
        axis.line = element_line(colour = "black",size = 1))+theme(legend.position="none")+scale_color_discrete(name  ="Nest fate",breaks=c(0, 1),labels=c("Failed", "Successful"))
fig2.1


# Nest success~ female weight
model2.2 <- glmer(nest_fate ~ Female_weight  + (1|Year), family = binomial (link = "logit"), data = df2.5)
isSingular(model2.2, tol = 1e-05)
summary(model2.2)

coef <- fixef(model2.2)  
se <- sqrt(diag(vcov(model2.2))) 
null_value <- 0
wald_test_statistic <- (coef["Female_weight"] - null_value) / se["Female_weight"]
wald_test_statistic
p_value <- 1 - pchisq(wald_test_statistic^2, df = 1)
p_value

# Nest success~ male tarsus
model2.3 <- glmer(nest_fate ~ male_tarsus  + (1|Year), family = binomial (link = "logit"), data = df2.5)
isSingular(model2.3, tol = 1e-05)
summary(model2.3)

coef <- fixef(model2.3)  
se <- sqrt(diag(vcov(model2.3))) 
null_value <- 0
wald_test_statistic <- (coef["male_tarsus"] - null_value) / se["male_tarsus"]
wald_test_statistic
p_value <- 1 - pchisq(wald_test_statistic^2, df = 1)
p_value


# Egg volumn ~ female weight
df2 <- mutate(df2, mean_volume = rowMeans(select(df2, egg_1_volume, egg_2_volume, egg_3_volume), na.rm = TRUE))

model2.4 <- lmer(mean_volume ~ Female_weight  + (1|Year), REML = TRUE, data = df2)
summary(model2.4)

coef <- fixef(model2.4)  
se <- sqrt(diag(vcov(model2.4))) 
null_value <- 0
wald_test_statistic <- (coef["Female_weight"] - null_value) / se["Female_weight"]
wald_test_statistic
p_value <- 1 - pchisq(wald_test_statistic^2, df = 1)
p_value

# DSR analysis

install.packages("survival")
library(survival)
library(survminer)  # Required for ggsurvplot
library(ggplot2)


shorebird_data_1 <- read.csv("DSR.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")
shorebird_data_2 <- read.csv("founddate.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")

shorebird_data<- merge(shorebird_data_1, shorebird_data_2, by = "Nest_ID")
write.csv(shorebird_data,'DSR_1.csv')

shorebird_data <- read.csv("DSR_1.csv",header = TRUE, sep = ",", dec = ".",na.strings = "NA")
View(shorebird_data)

shorebird_data $Year <- as.factor(shorebird_data$Year.x)


shorebird_data <- shorebird_data %>%
  filter(!is.na(Founddate), !is.na(Enddate)) %>%
  mutate(Founddate = as.Date(as.character(Founddate), format = "%Y%m%d"),
         Enddate = as.Date(as.character(Enddate), format = "%Y%m%d"),
         Event = ifelse(Nest_fate_2 %in% c("PREDATED", "FAILED"), 1, 0),
         Time = as.numeric(Enddate - Founddate))

View(shorebird_data)

surv_fit <- survfit(Surv(Time, Event) ~ strata(Year), data = shorebird_data)

# Summarize the survival curve
summary(surv_fit)


# Plot the survival curve
surv_plot <- ggsurvplot(surv_fit, 
                         data = shorebird_data, 
                         conf.int = TRUE,  # Include standard error bands
                         xlab = "Days")


surv_plot










